document.getElementById("searchBox").addEventListener("input", function () {
  let searchValue = this.value.toLowerCase();
  let cards = document.querySelectorAll(".post-card");

  cards.forEach(card => {
    let title = card.querySelector("h3").innerText.toLowerCase();
    let content = card.querySelector("p").innerText.toLowerCase();

    if (title.includes(searchValue) || content.includes(searchValue)) {
      card.style.display = "block";
    } else {
      card.style.display = "none";
    }
  });
});