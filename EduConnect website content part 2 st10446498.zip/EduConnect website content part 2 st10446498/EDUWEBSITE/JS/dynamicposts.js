// Sample dynamic data 
const posts = [
  {
    title: "5 Study Tips to Improve Your Grades",
    content: "Break your study time into sessions, use past papers, teach others and stay consistent."
  },
  {
    title: "How to Beat Exam Stress",
    content: "Use relaxation techniques, plan early, and take care of your sleep."
  },
  {
    title: "The Power of Personalized Tutoring",
    content: "Learners improve faster with tailored support and guidance."
  }
];

// Load dynamic content
function loadPosts() {
  const container = document.getElementById("postContainer");

  posts.forEach(post => {
    const card = document.createElement("div");
    card.className = "post-card";
    card.innerHTML = `
      <h3>${post.title}</h3>
      <p>${post.content}</p>
    `;
    container.appendChild(card);
  });
}

window.onload = loadPosts;