#PART 1


#PART2
### *changes made in the homepage are as follows:*
1. Fixed broken HTML tags (‹ › → < >, moved misplaced </u>).
	2.	Added semantic structure (<header>, <main>, <section>, <footer>).
	3.	Added a hero section with background image and headline.
	4.	Added content sections (About, Highlights, Testimonials, Call-to-Action).

	### *changes made in all pages to fix errors and improve the html pages.*
	### 1. *HTML Pages*
- *Homepage (index.html)*  
  - Hero banner with background image and call-to-action button.  
  - About, Vision & Mission sections.  
  - Subjects, services, testimonials, partnerships, and FAQs.  
  - Fully responsive layout with clear navigation.  

- *About Page (about.html)*  
  - History of EduConnect Academy.  
  - Mission, Vision, and "Why Choose Us" section with bullet points.  
  - Button linking to Contact page.  

- *Services Page (services.html)*  
  - Grid layout with *cards* for tutoring categories:  
    - Primary & High School, University Support, Professional Upskilling.  
  - Added descriptions for each card.  

- *Blog Page (blog.html)*  
  - Resources & Study Tips.  
  - Article posts: “5 Study Tips to Improve Your Grades” & “How to Beat Exam Stress.”  
  - Ordered list styled for readability.  

- *Contact Page (contact.html)*  
  - Responsive contact form (Name, Email, Subject, Message).  
  - Form uses :focus pseudo-class for accessibility.  
  - Contact details section with email, phone, and address.  
  - Embedded EduConnect logo.

### 2. *Added CSS Adjustments for each page*
- *Layout*:  
  - Multi-column grids on desktop, switching to single-column on mobile via media queries.  
  - Max-width applied to content for readability.  
  - Flexbox and Grid used for alignment.  

- *Typography*:  
  - Relative units (rem, %) for font sizes.  
  - Different font sizes for desktop, tablet, and mobile.  

- *Decoration*:  
  - Hover effects for buttons and links.  
  - Box shadows and border-radius for cards.  
  - Wavy underline for headings.  

- *Pseudo-classes*:  
  - :hover for buttons and navigation links.  
  - :focus for input fields in forms.  

- *Responsive Design (Media Queries)*:  
  - *Desktop (>1024px)* → Multi-column layouts.  
  - *Tablet (768px - 1024px)* → Adjusted font sizes, two-column layouts.  
  - *Mobile (<480px)* → Single-column layout, buttons at 100% width, smaller fonts.  

- *Responsive Images*:  
  - Logo and hero images scale using % widths.  
  - Background images set with background-size: cover.

  ##  Responsive Testing Evidence
The website was tested on multiple devices and screen sizes using browser developer tools:  

- *Desktop (1920px)* → Full multi-column layout.  
- *Tablet (768px)* → Layout adjusts to two columns, font sizes reduced.  
- *Mobile (375px)* → Single-column stack, buttons scale to 100%.

![alt tablet](IMAGES/ipad.png) ![alt mobile](IMAGES/mobile.png) ![alt desktop](IMAGES/desktop.png)

##  Changelog  

### v1.0 – Initial Setup  
- Created project structure with index.html and css/style.css.  
- Added navigation and hero section.  

### v1.1 – Additional Pages  
- Added about.html, services.html, blog.html, and contact.html.  
- Linked navigation between all pages.  

### v1.2 – Responsive Design  
- Added *media queries* for desktop, tablet, and mobile.  
- Converted font sizes and spacing to relative units (rem, %).  

### v1.3 – Enhancements  
- Added hover effects and shadows for visual appeal.  
- Improved contact form accessibility with pseudo-classes (:focus).  
- Implemented responsive images.

##  References  

- MDN Web Docs: [https://developer.mozilla.org/](https://developer.mozilla.org/)  
- W3Schools Responsive Design Guide: [https://www.w3schools.com/css/css_rwd_intro.asp](https://www.w3schools.com/css/css_rwd_intro.asp)  
- Unsplash (Hero Images): [https://unsplash.com/](https://unsplash.com/)  
- FreeCodeCamp Responsive Web Design: [https://www.freecodecamp.org/](https://www.freecodecamp.org/)


##  GitHub Workflow  

- Project pushed to GitHub with *multiple descriptive commits* at each stage of development.  
  - Example commit messages:  
    - Added services page with tutoring cards  
    - Implemented media queries for tablet and mobile  
    - Styled contact form with focus pseudo-class  
    - `Updated README with project documentation
	[text](https://github.com/stito101/educonnect-website.git)