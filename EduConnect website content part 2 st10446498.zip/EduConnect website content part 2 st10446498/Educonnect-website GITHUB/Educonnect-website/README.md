# EDUCONNECT-WEBSITE


## EduConnect Academy Website

## Project Title
EduConnect Academy Website

## Student Information
	•	Name: Thato Ramphomane
	•	Student Number: St10446498
	•	module: WEB DEVELOPMENT
	•	Institution: Rosebank college

## Project Overview

The EduConnect Academy Website is designed to showcase an educational institution offering tutoring and blended learning solutions. The project demonstrates foundational to intermediate web development skills, including HTML, CSS, JavaScript, responsiveness, and GitHub integration.

## Website Goals and Objectives
	•	Build a professional and responsive multi-page website.
	•	Highlight EduConnect Academy’s mission, vision, and services.
	•	Provide easy navigation and accessibility.
	•	Showcase web development skills in HTML, CSS, and JavaScript.
	•	Optimize the website for SEO and user experience.

## Key Features and Functionality
	•	Homepage: Overview of EduConnect Academy.
	•	About Page: History, mission, vision, and reasons to choose EduConnect.
	•	Services Page: Tutoring and blended learning offerings.
	•	Contact Page: Form for inquiries and location info.
	•	Blog Page: Space for future educational articles.
	•	Responsive Design: Works on desktops, tablets, and mobiles.
	•	GitHub Integration: Version control with commit history.

## Timeline and Milestones
	•	Part 1: HTML structure with basic content.
	•	Part 2: Add CSS styling and responsiveness.
	•	Part 3: Add JavaScript functionality and interactivity.

## Part 1 Details
	•	Set up project folder and GitHub repository.
	•	Added initial HTML pages (index, about, services, contact, blog).
	•	Inserted basic structure and placeholder content.
	•	Pushed first commit to GitHub.

(Parts 2 and 3 will be added in future submissions.)

## Sitemap
	•	Home (index.html)
	•	About (about.html)
	•	Services (services.html)
	•	Contact (contact.html)
	•	Blog (blog.html)

## Changelog
	•	v1.0 (25 Aug 2025): Initial project setup, folder structure, HTML skeleton created.
	•	v1.1 (26 Aug 2025): Added mission, vision, and why choose us content.

## References
	•	Free Images: Unsplash, Pixabay, Pexels
	•	Icons: Font Awesome
	•	Fonts: Google Fonts – Montserrat
	•	HTML/CSS/JS Docs: W3Schools, MDN Web Docs
